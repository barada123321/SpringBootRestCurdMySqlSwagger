# SpringBoot2RestCurdMySQLSwagger
Spring Boot Back Application for Angular UI
Angular UI code:
https://www.mediafire.com/file/4ryjspntsrn32ff/spring-boot-angular-ui-code.zip/file
